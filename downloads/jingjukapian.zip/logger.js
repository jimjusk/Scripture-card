// 日志记录器
class Logger {
  static error(...args) {
    console.error(...args);
  }
  
  static warn(...args) {
    console.warn(...args);
  }
  
  static info(...args) {
    console.info(...args);
  }
}

export default Logger; 